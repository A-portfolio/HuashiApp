package net.muxi.huashiapp.ui.timeTable;

/**
 * Created by ybao on 16/5/10.
 */
public interface OnWeekChangeListener {
    void OnWeekChange(int week);
}

package net.muxi.huashiapp.ui.location.data;

import java.util.List;

public class PointSearch {


    /**
     * name : 华中师范大学图书馆
     * points : [30.526257,114.36735]
     */

    private String name;
    private List<Double> points;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Double> getPoints() {
        return points;
    }

    public void setPoints(List<Double> points) {
        this.points = points;
    }
}

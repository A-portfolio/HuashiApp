package net.muxi.huashiapp.statistics;

import android.util.Log;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

public class StatisticsAspect {


    public static final String TAG="statistics";

    //activity打开统计
    @Pointcut("execution(*ToolbarActivity.onCreate(..)")
    public void activityCreate(){}

    @After("activityCreate()")
    public void afterActivityCreate(JoinPoint point){
        Log.i(TAG, "afterActivityCreate: target--->"+point.getTarget());
        Log.i(TAG, "afterActivityCreate: this--->"+point.getThis());
        Log.i(TAG, "afterActivityCreate: arg-->"+point.getArgs()[0].toString());


    }


}

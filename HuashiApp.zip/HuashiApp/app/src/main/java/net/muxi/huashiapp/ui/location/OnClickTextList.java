package net.muxi.huashiapp.ui.location;
import com.amap.api.services.core.LatLonPoint;

public interface OnClickTextList {
    void onClickText(String s, LatLonPoint l);
}

package net.muxi.huashiapp.ui.timeTable;

import com.muxistudio.appcommon.data.Course;

/**
 * Created by ybao on 17/1/27.
 */

public interface OnCourseClickListener {

    void onCourseClick(Course course);
}

package com.muxistudio.common.jsbridge;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/4/3
 */

public interface CallbackFunc {

    void onCallback(String data);
}

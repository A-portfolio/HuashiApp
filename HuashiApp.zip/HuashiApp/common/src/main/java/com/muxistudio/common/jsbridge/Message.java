package com.muxistudio.common.jsbridge;

/**
 * Created by ybao on 16/10/11.
 */

public class Message {

    public String event;
    public Object data;
    public int id;
}

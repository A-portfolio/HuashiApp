package com.muxistudio.appcommon.data;

/**
 * Created by december on 17/4/12.
 */

public class CardSumData {
    public String time;
    public double sum;

    public CardSumData(String time, double sum) {
        this.time = time;
        this.sum = sum;
    }
}

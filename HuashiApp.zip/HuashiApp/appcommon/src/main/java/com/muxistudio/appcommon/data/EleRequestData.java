package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/8/3.
 */
public class EleRequestData {

    public String dor;
    public String type;

    public String getDor() {
        return dor;
    }

    public void setDor(String dor) {
        this.dor = dor;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

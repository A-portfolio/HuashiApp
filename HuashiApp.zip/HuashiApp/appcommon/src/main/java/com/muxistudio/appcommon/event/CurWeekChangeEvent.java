package com.muxistudio.appcommon.event;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/4/30
 */

public class CurWeekChangeEvent {
}

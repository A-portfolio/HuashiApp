package com.muxistudio.appcommon.event;

/**
 * Created by december on 17/5/12.
 */

public class RefreshBanner {
}

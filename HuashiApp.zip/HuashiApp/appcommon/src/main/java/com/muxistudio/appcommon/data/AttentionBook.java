package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 17/2/21.
 */

public class AttentionBook {

        public String bid;
        public String book;
        public String id;
        public String author;
        public String avb;

}

package com.muxistudio.appcommon.data;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/4/30
 */

public class CourseId {

    public int id;
}

package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 17/2/22.
 */

public class BookId {

    public String id;
}

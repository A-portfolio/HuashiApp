package com.muxistudio.appcommon.event;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/4/21
 */

public class RefreshAttenBooks {
}

package com.muxistudio.appcommon.event;

/**
 * Created by fengminchao on 18/3/19
 * event 的集合 class
 */

public class EventClass {
}

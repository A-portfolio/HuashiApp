package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 17/2/21.
 */

public class RenewData {

    public String bar_code;
    public String check;
}

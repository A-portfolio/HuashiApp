package com.muxistudio.appcommon.data;

/**
 * Created by december on 16/11/2.
 */

public class WebsiteData {

    public String url;
    public String site;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }
}

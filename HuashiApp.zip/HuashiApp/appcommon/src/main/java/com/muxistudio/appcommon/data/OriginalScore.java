package com.muxistudio.appcommon.data;

import java.util.List;

public class OriginalScore {


    /**
     * currentPage : 1
     * currentResult : 0
     * entityOrField : false
     * items : [{"bfzcj":71,"bh_id":"20172201","bj":"20172201","cj":"71.6","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"2.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"方文波","jxb_id":"6CEE14B841F065DEE0531D50A8C0BFF6","jxbmc":"2  物理","kcbj":"主修","kcgsmc":"理","kch":"31002011","kch_id":"31002011","kclbmc":"专业课","kcmc":"高等数学A1","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6CEE14B841F065DEE0531D50A8C0BFF6!!2017212163","kkbmmc":"数学与统计学学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"1","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"6.0","xh":"2017212163","xh_id":"710995d2306f41cd760e2a7bd46f8a3392af23c902b4857027fb4af5ee7796024a9a107d430ea112bc750add153fd6e4b13a79a2516bb9e5205167c0461d285c3eb98146839335ce36e4804fe9dd761261c5ce47a309bddbee251b6689d6b18f61e4ec540418e1847cfa7cd9a0bf4575e114ae192ac693c9247b9b2245a0f1b6","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":74,"bh_id":"20172201","bj":"20172201","cj":"74.6","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"2.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"李书刚","jxb_id":"6CF47585C0876452E0531E50A8C0A106","jxbmc":"6  计算机","kcbj":"主修","kcgsmc":"理","kch":"31002051","kch_id":"31002051","kclbmc":"专业课","kcmc":"线性代数A","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6CF47585C0876452E0531E50A8C0A106!!2017212163","kkbmmc":"数学与统计学学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"2","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"3.0","xh":"2017212163","xh_id":"4ae2b394ba1072ba13c0bb8fab32f4c570fb5ef1ed4ec2d162d3b0ab1e35e24cc311d367bb0fefe38f01c9e38449c35477066d69d1736a5fe1a27f7e7202bf69754d90d8b4aecb2bd913169d14f3c58553846716800c9093eff6f3527292834d1f23e0d732b8a931f38cda4ed146aa0a1eed2124aaec3d21c34762c4d587e2be","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":63,"bh_id":"20172201","bj":"20172201","cj":"63.2","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"1.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"胡建伟","jxb_id":"6D0307D7F1592062E0531D50A8C0A152","jxbmc":"8  计算机","kcbj":"主修","kcgsmc":"理","kch":"31002061","kch_id":"31002061","kclbmc":"专业课","kcmc":"概率统计A","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6D0307D7F1592062E0531D50A8C0A152!!2017212163","kkbmmc":"数学与统计学学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"3","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"3.0","xh":"2017212163","xh_id":"154b501acdddc7ae3190981cbdbfc07a80e894e77251ea3f7547e975218388812ccb733d4ddc1a1548b198bbbe8ee38f9d38816094e80a9fa2d242e5cb1d4437f3a65bff5b62a439aed5c107a5c55e95fad07e43c2bca036f111bb0bd1fe52051e42185c1cccdb913571cd683e629b7fefbc5eae31c1545d7feed8f4143f51f9","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":80,"bh_id":"20172201","bj":"20172201","cj":"80.0","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"3.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"李凯","jxb_id":"6DF21E7E35A7435FE0531D50A8C098A6","jxbmc":"101课堂  足球","kcbj":"主修","kcgsmc":"体","kch":"33003100","kch_id":"33003100","kclbmc":"公共课","kcmc":"大学体育3","kcxzdm":"23","kcxzmc":"通识必修课","key":"6DF21E7E35A7435FE0531D50A8C098A6!!2017212163","kkbmmc":"公共体育","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"4","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"1.0","xh":"2017212163","xh_id":"6c52220a742e06b735a47ace6bfdaec2ab00d0860a17a4c65b2abe8c04ba747ba764ec8c47decc958a489a3fde0face5a8269f75a4fcb74070d65faa72b322c2c4cb46f1180e983b4d1c721e082bb0a877e032f58fe6df3cdb58f064307d2951022e9074dd257a30fb3bd17d31ea9851f8f5d308a8e8ef60a32d5413d3327a43","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":82,"bh_id":"20172201","bj":"20172201","cj":"82.6","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"3.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"石智刚","jxb_id":"6CADF22BE08A213BE0531E50A8C0AA73","jxbmc":"6","kcbj":"主修","kcgsmc":"文","kch":"34000025","kch_id":"34000025","kclbmc":"公共课","kcmc":"毛泽东思想和中国特色社会主义理论体系概论","kcxzdm":"30","kcxzmc":"专业选修课","key":"6CADF22BE08A213BE0531E50A8C0AA73!!2017212163","kkbmmc":"理论课部","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"5","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"6.0","xh":"2017212163","xh_id":"674c10a6a91668220ad5f80e689c88c4f14cace47869ec040803b6d0445d858decef7c27888ca8ca26c0126c9316894fe29d303813b5d79abd2c0d3cf496c4a48ac8ea39ae2ffeb7a5ef8deeea16b3a1019bea0695b205cdafe80fa299e8f7d5dddad1225810aa97db0ed24619ff21ab7945b0faa1a8d2a24141ba296f1314f1","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":73,"bh_id":"20172201","bj":"20172201","cj":"73.4","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"2.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"刘滟","jxb_id":"6CAD90D7F85F197CE0531E50A8C0D946","jxbmc":"66","kcbj":"主修","kch":"35000113","kch_id":"208A7EC7AB55305DE0531D50A8C0D6AE","kclbmc":"公共课","kcmc":"大学英语（JR3）","kcxzdm":"23","kcxzmc":"通识必修课","key":"6CAD90D7F85F197CE0531E50A8C0D946!!2017212163","kkbmmc":"公共外语","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"6","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"2.0","xh":"2017212163","xh_id":"324db09808c37cb90bb14cececffc4864c1b4c5b6a3c9ab7cb99fc1f5e2082a412edfa766d87b63074b67ed2b92fd80002795d11cd012fe77ac6d7af7e394444f4d1da0c8a09d137c034812fb4b148e171b46da60353e31070feac8d3e65412810e55b234caa12c11159a24b6d8322725945027280eb37e26de50c65a734f769","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":73,"bh_id":"20172201","bj":"20172201","cj":"73.2","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"2.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"刘滟","jxb_id":"6CB7A57493FF4BC2E0531E50A8C0506E","jxbmc":"66","kcbj":"主修","kch":"35000213","kch_id":"208A7EC7AB65305DE0531D50A8C0D6AE","kclbmc":"公共课","kcmc":"大学英语视听说（JL3）","kcxzdm":"23","kcxzmc":"通识必修课","key":"6CB7A57493FF4BC2E0531E50A8C0506E!!2017212163","kkbmmc":"公共外语","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"7","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"2.0","xh":"2017212163","xh_id":"688103c9c625062ba31d7549b5fa1878f32236cab82fd127048b37ec06cafb8837bcaa9310229db1b34f33de332f47a4d8ce5114d99f1abfc6767af39132e29a50843fac2ea146bd4eec3975d3409ce9baf72be845694dfaa71d7522c9fade05086b0f325d587ec34f2cf007376382c3836f3b7ad115cfd4ce7736270f547a98","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":85,"bh_id":"20172201","bj":"20172201","cj":"85.4","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"3.50","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"沈显君","jxb_id":"6CEF709CB83B34FCE0531E50A8C030A9","jxbmc":"2","kcbj":"主修","kcgsmc":"理","kch":"48740005","kch_id":"48740005","kclbmc":"公共课","kcmc":"数据结构","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6CEF709CB83B34FCE0531E50A8C030A9!!2017212163","kkbmmc":"计算机学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"8","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"4.0","xh":"2017212163","xh_id":"1ff72a9d50895775294d2eff6120e615224675eccc04ff5e0086eec94a20d5df0cc3473727f895bfd4ba4783ac2d9f658a2cc0febea242af2919eb76c5b8ac5ab7a80169aff04a98bded7cc766742b0cb57a3fe3a9a06ea3ee77f7c8477bb04ba9745ef14796dcc9d5a6ed1def2c16c07054eda549962d83d17beef5b4e23772","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":84,"bh_id":"20172201","bj":"20172201","cj":"84.4","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"3.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"沈显君","jxb_id":"6CEEA6BE07EE2523E0531E50A8C0B085","jxbmc":"2","kcbj":"主修","kcgsmc":"理","kch":"48740006","kch_id":"48740006","kclbmc":"公共课","kcmc":"数据结构实验","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6CEEA6BE07EE2523E0531E50A8C0B085!!2017212163","kkbmmc":"计算机学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"9","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"1.0","xh":"2017212163","xh_id":"82bc77afbe3cf82af29b3dc186484a22452328d6fda1d03d9f4af6430582a8315b712c4521e87e352d57172490df8b02278146071fa7e383398c923f9419b24fdf01b9ef39331d21919d9c1018f725b950a0ae3b6fbae2d81f25757251b63832e6e42fedd6ae62c27a94150aa083ea3d20989aa6552dead080535eef66a77c29","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":78,"bh_id":"20172201","bj":"20172201","cj":"78.6","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"2.50","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"赵甫哲","jxb_id":"6CEF709CB88E34FCE0531E50A8C030A9","jxbmc":"4","kcbj":"主修","kcgsmc":"理","kch":"48740007","kch_id":"48740007","kclbmc":"公共课","kcmc":"数字逻辑","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6CEF709CB88E34FCE0531E50A8C030A9!!2017212163","kkbmmc":"计算机学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"10","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"3.5","xh":"2017212163","xh_id":"28e7b245f09cd1ef78f3e945473245e10b25be241965ad90c11e43105bb1cf4d742565d5f5371254fc036066d8e07de8c6af63a58e168508b4fe91553eeb8b049aff8257b33269a137b6d9d636480e84ecbd4f184ed15fff8497485672de67c88539a0e14c91c56510a1f9905937f212e3ff3fad5f9e716d1ef3d84542ee11e8","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"},{"bfzcj":84,"bh_id":"20172201","bj":"20172201","cj":"84.6","cjsfzf":"否","date":"null年一月一日","dateDigit":"2019年5月16日","day":"1","jd":"3.00","jg_id":"6900","jgmc":"计算机学院","jgpxzd":"1","jsxm":"胡珀","jxb_id":"6CF033B80A2940ECE0531E50A8C045CF","jxbmc":"2","kcbj":"主修","kcgsmc":"理","kch":"48740008","kch_id":"48740008","kclbmc":"公共课","kcmc":"面向对象程序设计","kcxzdm":"26","kcxzmc":"专业主干课程","key":"6CF033B80A2940ECE0531E50A8C045CF!!2017212163","kkbmmc":"计算机学院","ksxz":"正常考试","ksxzdm":"01","listnav":"false","localeKey":"zh_CN","month":"1","njdm_id":"2017","njmc":"2017","pageable":true,"queryModel":{"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0},"rangeable":true,"row_id":"11","sfxwkc":"否","totalResult":"11","userModel":{"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false},"xb":"男","xbm":"1","xf":"3.5","xh":"2017212163","xh_id":"0a50988db8ad3e12dd1234f4c061a2d7fcffd07845e716cc82f6a4e3f03c4a3df7f20cf1098cea2e7086c4c4a6d186b9773df7415ec718ffa3f0559370e5fbe13e93d0642e73df888484fd564d9b9a1e57acbf48040a8e748c300c0d8a64a6ea6184b76d977aab184febd8536eab0943ed725c9e8c7b22f739e664c0bebe6b57","xm":"王鹏宇","xnm":"2018","xnmmc":"2018-2019","xqm":"3","xqmmc":"1","zyh_id":"220","zymc":"计算机类_220"}]
     * limit : 15
     * offset : 0
     * pageNo : 0
     * pageSize : 15
     * showCount : 15
     * sortName : xnmmc asc,xqmmc asc
     * sortOrder :
     * sorts : []
     * totalCount : 11
     * totalPage : 1
     * totalResult : 11
     */

    private int currentPage;
    private int currentResult;
    private boolean entityOrField;
    private int limit;
    private int offset;
    private int pageNo;
    private int pageSize;
    private int showCount;
    private String sortName;
    private String sortOrder;
    private int totalCount;
    private int totalPage;
    private int totalResult;
    private List<ItemsBean> items;
    private List<?> sorts;

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getCurrentResult() {
        return currentResult;
    }

    public void setCurrentResult(int currentResult) {
        this.currentResult = currentResult;
    }

    public boolean isEntityOrField() {
        return entityOrField;
    }

    public void setEntityOrField(boolean entityOrField) {
        this.entityOrField = entityOrField;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getShowCount() {
        return showCount;
    }

    public void setShowCount(int showCount) {
        this.showCount = showCount;
    }

    public String getSortName() {
        return sortName;
    }

    public void setSortName(String sortName) {
        this.sortName = sortName;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalResult() {
        return totalResult;
    }

    public void setTotalResult(int totalResult) {
        this.totalResult = totalResult;
    }

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    public List<?> getSorts() {
        return sorts;
    }

    public void setSorts(List<?> sorts) {
        this.sorts = sorts;
    }

    public static class ItemsBean {
        /**
         * bfzcj : 71
         * bh_id : 20172201
         * bj : 20172201
         * cj : 71.6
         * cjsfzf : 否
         * date : null年一月一日
         * dateDigit : 2019年5月16日
         * day : 1
         * jd : 2.00
         * jg_id : 6900
         * jgmc : 计算机学院
         * jgpxzd : 1
         * jsxm : 方文波
         * jxb_id : 6CEE14B841F065DEE0531D50A8C0BFF6
         * jxbmc : 2  物理
         * kcbj : 主修
         * kcgsmc : 理
         * kch : 31002011
         * kch_id : 31002011
         * kclbmc : 专业课
         * kcmc : 高等数学A1
         * kcxzdm : 26
         * kcxzmc : 专业主干课程
         * key : 6CEE14B841F065DEE0531D50A8C0BFF6!!2017212163
         * kkbmmc : 数学与统计学学院
         * ksxz : 正常考试
         * ksxzdm : 01
         * listnav : false
         * localeKey : zh_CN
         * month : 1
         * njdm_id : 2017
         * njmc : 2017
         * pageable : true
         * queryModel : {"currentPage":1,"currentResult":0,"entityOrField":false,"limit":15,"offset":0,"pageNo":0,"pageSize":15,"showCount":10,"sorts":[],"totalCount":0,"totalPage":0,"totalResult":0}
         * rangeable : true
         * row_id : 1
         * sfxwkc : 否
         * totalResult : 11
         * userModel : {"monitor":false,"roleCount":0,"roleKeys":"","roleValues":"","status":0,"usable":false}
         * xb : 男
         * xbm : 1
         * xf : 6.0
         * xh : 2017212163
         * xh_id : 710995d2306f41cd760e2a7bd46f8a3392af23c902b4857027fb4af5ee7796024a9a107d430ea112bc750add153fd6e4b13a79a2516bb9e5205167c0461d285c3eb98146839335ce36e4804fe9dd761261c5ce47a309bddbee251b6689d6b18f61e4ec540418e1847cfa7cd9a0bf4575e114ae192ac693c9247b9b2245a0f1b6
         * xm : 王鹏宇
         * xnm : 2018
         * xnmmc : 2018-2019
         * xqm : 3
         * xqmmc : 1
         * zyh_id : 220
         * zymc : 计算机类_220
         */

        private int bfzcj;
        private String bh_id;
        private String bj;
        private String cj;
        private String cjsfzf;
        private String date;
        private String dateDigit;
        private String day;
        private String jd;
        private String jg_id;
        private String jgmc;
        private String jgpxzd;
        private String jsxm;
        private String jxb_id;
        private String jxbmc;
        private String kcbj;
        private String kcgsmc;
        private String kch;
        private String kch_id;
        private String kclbmc;
        private String kcmc;
        private String kcxzdm;
        private String kcxzmc;
        private String key;
        private String kkbmmc;
        private String ksxz;
        private String ksxzdm;
        private String listnav;
        private String localeKey;
        private String month;
        private String njdm_id;
        private String njmc;
        private boolean pageable;
        private QueryModelBean queryModel;
        private boolean rangeable;
        private String row_id;
        private String sfxwkc;
        private String totalResult;
        private UserModelBean userModel;
        private String xb;
        private String xbm;
        private String xf;
        private String xh;
        private String xh_id;
        private String xm;
        private String xnm;
        private String xnmmc;
        private String xqm;
        private String xqmmc;
        private String zyh_id;
        private String zymc;

        public int getBfzcj() {
            return bfzcj;
        }

        public void setBfzcj(int bfzcj) {
            this.bfzcj = bfzcj;
        }

        public String getBh_id() {
            return bh_id;
        }

        public void setBh_id(String bh_id) {
            this.bh_id = bh_id;
        }

        public String getBj() {
            return bj;
        }

        public void setBj(String bj) {
            this.bj = bj;
        }

        public String getCj() {
            return cj;
        }

        public void setCj(String cj) {
            this.cj = cj;
        }

        public String getCjsfzf() {
            return cjsfzf;
        }

        public void setCjsfzf(String cjsfzf) {
            this.cjsfzf = cjsfzf;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getDateDigit() {
            return dateDigit;
        }

        public void setDateDigit(String dateDigit) {
            this.dateDigit = dateDigit;
        }

        public String getDay() {
            return day;
        }

        public void setDay(String day) {
            this.day = day;
        }

        public String getJd() {
            return jd;
        }

        public void setJd(String jd) {
            this.jd = jd;
        }

        public String getJg_id() {
            return jg_id;
        }

        public void setJg_id(String jg_id) {
            this.jg_id = jg_id;
        }

        public String getJgmc() {
            return jgmc;
        }

        public void setJgmc(String jgmc) {
            this.jgmc = jgmc;
        }

        public String getJgpxzd() {
            return jgpxzd;
        }

        public void setJgpxzd(String jgpxzd) {
            this.jgpxzd = jgpxzd;
        }

        public String getJsxm() {
            return jsxm;
        }

        public void setJsxm(String jsxm) {
            this.jsxm = jsxm;
        }

        public String getJxb_id() {
            return jxb_id;
        }

        public void setJxb_id(String jxb_id) {
            this.jxb_id = jxb_id;
        }

        public String getJxbmc() {
            return jxbmc;
        }

        public void setJxbmc(String jxbmc) {
            this.jxbmc = jxbmc;
        }

        public String getKcbj() {
            return kcbj;
        }

        public void setKcbj(String kcbj) {
            this.kcbj = kcbj;
        }

        public String getKcgsmc() {
            return kcgsmc;
        }

        public void setKcgsmc(String kcgsmc) {
            this.kcgsmc = kcgsmc;
        }

        public String getKch() {
            return kch;
        }

        public void setKch(String kch) {
            this.kch = kch;
        }

        public String getKch_id() {
            return kch_id;
        }

        public void setKch_id(String kch_id) {
            this.kch_id = kch_id;
        }

        public String getKclbmc() {
            return kclbmc;
        }

        public void setKclbmc(String kclbmc) {
            this.kclbmc = kclbmc;
        }

        public String getKcmc() {
            return kcmc;
        }

        public void setKcmc(String kcmc) {
            this.kcmc = kcmc;
        }

        public String getKcxzdm() {
            return kcxzdm;
        }

        public void setKcxzdm(String kcxzdm) {
            this.kcxzdm = kcxzdm;
        }

        public String getKcxzmc() {
            return kcxzmc;
        }

        public void setKcxzmc(String kcxzmc) {
            this.kcxzmc = kcxzmc;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getKkbmmc() {
            return kkbmmc;
        }

        public void setKkbmmc(String kkbmmc) {
            this.kkbmmc = kkbmmc;
        }

        public String getKsxz() {
            return ksxz;
        }

        public void setKsxz(String ksxz) {
            this.ksxz = ksxz;
        }

        public String getKsxzdm() {
            return ksxzdm;
        }

        public void setKsxzdm(String ksxzdm) {
            this.ksxzdm = ksxzdm;
        }

        public String getListnav() {
            return listnav;
        }

        public void setListnav(String listnav) {
            this.listnav = listnav;
        }

        public String getLocaleKey() {
            return localeKey;
        }

        public void setLocaleKey(String localeKey) {
            this.localeKey = localeKey;
        }

        public String getMonth() {
            return month;
        }

        public void setMonth(String month) {
            this.month = month;
        }

        public String getNjdm_id() {
            return njdm_id;
        }

        public void setNjdm_id(String njdm_id) {
            this.njdm_id = njdm_id;
        }

        public String getNjmc() {
            return njmc;
        }

        public void setNjmc(String njmc) {
            this.njmc = njmc;
        }

        public boolean isPageable() {
            return pageable;
        }

        public void setPageable(boolean pageable) {
            this.pageable = pageable;
        }

        public QueryModelBean getQueryModel() {
            return queryModel;
        }

        public void setQueryModel(QueryModelBean queryModel) {
            this.queryModel = queryModel;
        }

        public boolean isRangeable() {
            return rangeable;
        }

        public void setRangeable(boolean rangeable) {
            this.rangeable = rangeable;
        }

        public String getRow_id() {
            return row_id;
        }

        public void setRow_id(String row_id) {
            this.row_id = row_id;
        }

        public String getSfxwkc() {
            return sfxwkc;
        }

        public void setSfxwkc(String sfxwkc) {
            this.sfxwkc = sfxwkc;
        }

        public String getTotalResult() {
            return totalResult;
        }

        public void setTotalResult(String totalResult) {
            this.totalResult = totalResult;
        }

        public UserModelBean getUserModel() {
            return userModel;
        }

        public void setUserModel(UserModelBean userModel) {
            this.userModel = userModel;
        }

        public String getXb() {
            return xb;
        }

        public void setXb(String xb) {
            this.xb = xb;
        }

        public String getXbm() {
            return xbm;
        }

        public void setXbm(String xbm) {
            this.xbm = xbm;
        }

        public String getXf() {
            return xf;
        }

        public void setXf(String xf) {
            this.xf = xf;
        }

        public String getXh() {
            return xh;
        }

        public void setXh(String xh) {
            this.xh = xh;
        }

        public String getXh_id() {
            return xh_id;
        }

        public void setXh_id(String xh_id) {
            this.xh_id = xh_id;
        }

        public String getXm() {
            return xm;
        }

        public void setXm(String xm) {
            this.xm = xm;
        }

        public String getXnm() {
            return xnm;
        }

        public void setXnm(String xnm) {
            this.xnm = xnm;
        }

        public String getXnmmc() {
            return xnmmc;
        }

        public void setXnmmc(String xnmmc) {
            this.xnmmc = xnmmc;
        }

        public String getXqm() {
            return xqm;
        }

        public void setXqm(String xqm) {
            this.xqm = xqm;
        }

        public String getXqmmc() {
            return xqmmc;
        }

        public void setXqmmc(String xqmmc) {
            this.xqmmc = xqmmc;
        }

        public String getZyh_id() {
            return zyh_id;
        }

        public void setZyh_id(String zyh_id) {
            this.zyh_id = zyh_id;
        }

        public String getZymc() {
            return zymc;
        }

        public void setZymc(String zymc) {
            this.zymc = zymc;
        }

        public static class QueryModelBean {
            /**
             * currentPage : 1
             * currentResult : 0
             * entityOrField : false
             * limit : 15
             * offset : 0
             * pageNo : 0
             * pageSize : 15
             * showCount : 10
             * sorts : []
             * totalCount : 0
             * totalPage : 0
             * totalResult : 0
             */

            private int currentPage;
            private int currentResult;
            private boolean entityOrField;
            private int limit;
            private int offset;
            private int pageNo;
            private int pageSize;
            private int showCount;
            private int totalCount;
            private int totalPage;
            private int totalResult;
            private List<?> sorts;

            public int getCurrentPage() {
                return currentPage;
            }

            public void setCurrentPage(int currentPage) {
                this.currentPage = currentPage;
            }

            public int getCurrentResult() {
                return currentResult;
            }

            public void setCurrentResult(int currentResult) {
                this.currentResult = currentResult;
            }

            public boolean isEntityOrField() {
                return entityOrField;
            }

            public void setEntityOrField(boolean entityOrField) {
                this.entityOrField = entityOrField;
            }

            public int getLimit() {
                return limit;
            }

            public void setLimit(int limit) {
                this.limit = limit;
            }

            public int getOffset() {
                return offset;
            }

            public void setOffset(int offset) {
                this.offset = offset;
            }

            public int getPageNo() {
                return pageNo;
            }

            public void setPageNo(int pageNo) {
                this.pageNo = pageNo;
            }

            public int getPageSize() {
                return pageSize;
            }

            public void setPageSize(int pageSize) {
                this.pageSize = pageSize;
            }

            public int getShowCount() {
                return showCount;
            }

            public void setShowCount(int showCount) {
                this.showCount = showCount;
            }

            public int getTotalCount() {
                return totalCount;
            }

            public void setTotalCount(int totalCount) {
                this.totalCount = totalCount;
            }

            public int getTotalPage() {
                return totalPage;
            }

            public void setTotalPage(int totalPage) {
                this.totalPage = totalPage;
            }

            public int getTotalResult() {
                return totalResult;
            }

            public void setTotalResult(int totalResult) {
                this.totalResult = totalResult;
            }

            public List<?> getSorts() {
                return sorts;
            }

            public void setSorts(List<?> sorts) {
                this.sorts = sorts;
            }
        }

        public static class UserModelBean {
            /**
             * monitor : false
             * roleCount : 0
             * roleKeys :
             * roleValues :
             * status : 0
             * usable : false
             */

            private boolean monitor;
            private int roleCount;
            private String roleKeys;
            private String roleValues;
            private int status;
            private boolean usable;

            public boolean isMonitor() {
                return monitor;
            }

            public void setMonitor(boolean monitor) {
                this.monitor = monitor;
            }

            public int getRoleCount() {
                return roleCount;
            }

            public void setRoleCount(int roleCount) {
                this.roleCount = roleCount;
            }

            public String getRoleKeys() {
                return roleKeys;
            }

            public void setRoleKeys(String roleKeys) {
                this.roleKeys = roleKeys;
            }

            public String getRoleValues() {
                return roleValues;
            }

            public void setRoleValues(String roleValues) {
                this.roleValues = roleValues;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public boolean isUsable() {
                return usable;
            }

            public void setUsable(boolean usable) {
                this.usable = usable;
            }
        }
    }
}

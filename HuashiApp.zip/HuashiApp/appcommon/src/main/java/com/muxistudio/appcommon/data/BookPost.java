package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 17/2/21.
 */

public class BookPost {

    public String bid;
    public String book;
    public String book_id;
    public String author;
}

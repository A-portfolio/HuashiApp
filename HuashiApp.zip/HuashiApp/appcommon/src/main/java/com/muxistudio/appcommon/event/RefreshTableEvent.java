package com.muxistudio.appcommon.event;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/2/27
 */

public class RefreshTableEvent {

    public RefreshTableEvent() {
    }
}

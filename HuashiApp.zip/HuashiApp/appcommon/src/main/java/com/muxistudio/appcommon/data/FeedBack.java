package com.muxistudio.appcommon.data;

public class FeedBack {
  String contact;
  String content;

  public FeedBack(String contact,String content){
    this.contact = contact;
    this.content = content;
  }
}

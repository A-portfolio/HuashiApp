package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/7/24.
 */
public class CalendarData {


    /**
     * size : 3722x1440
     * update : 14712725420196685
     * img : http://oao7x1n3m.bkt.clouddn.com/Calendar-New.jpg
     * filename : Calendar-New.jpg
     */

    public String size;
    public long update;
    public String img;
    public String filename;

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public long getUpdate() {
        return update;
    }

    public void setUpdate(long update) {
        this.update = update;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
}

package com.muxistudio.appcommon.data;

/**
 * Created by kolibreath on 18-2-25.
 */

public class Msg {

    /**
     * msg : string
     */

    private String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

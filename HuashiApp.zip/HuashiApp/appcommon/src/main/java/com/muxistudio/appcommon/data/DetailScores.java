package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/8/7.
 */
public class DetailScores {

    public String course;
    public String usual;
    public String ending;

    public String getUsual() {
        return usual;
    }

    public void setUsual(String usual) {
        this.usual = usual;
    }

    public String getEnding() {
        return ending;
    }

    public void setEnding(String ending) {
        this.ending = ending;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}


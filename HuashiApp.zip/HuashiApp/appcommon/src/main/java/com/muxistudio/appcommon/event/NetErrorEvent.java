package com.muxistudio.appcommon.event;

/**
 * Created by kolibreath on 17-12-20.
 */

public class NetErrorEvent {

}

package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/8/20.
 */
public class SplashData {

    public String img;
    public String url;
    public long update;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getUpdate() {
        return update;
    }

    public void setUpdate(long update) {
        this.update = update;
    }
}

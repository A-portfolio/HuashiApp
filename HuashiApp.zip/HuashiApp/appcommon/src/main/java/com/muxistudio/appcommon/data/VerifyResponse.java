package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/6/21.
 */
public class VerifyResponse {

}

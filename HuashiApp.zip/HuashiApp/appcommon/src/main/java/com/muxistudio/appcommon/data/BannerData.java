package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/7/7.
 */
public class BannerData {
    /**
     * url : http://static.muxixyz.com/axmasbanner.png
     * num : 1
     * update : 14825813780118006
     * img : http://static.muxixyz.com/axmasbanner.png
     * filename : axmasbanner.png
     */

    private String url;
    private String num;
    private long update;
    private String img;
    private String filename;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public long getUpdate() {
        return update;
    }

    public void setUpdate(long update) {
        this.update = update;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }


}

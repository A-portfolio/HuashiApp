package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/4/28.
 */
public class MainLoginResponse{

    /**
     * status : 200
     */

    public int status;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}

package com.muxistudio.appcommon.data;

/**
 * Created by ybao on 16/6/21.
 */
public class BorrowedBook {

    public String itime;
    public String otime;
    public String book;
    public String room;
    public String author;
    public String bar_code;
    public int time;
    public String check;
    public String id;
}

package com.muxistudio.appcommon.data;

public class A {
  int sid ;
  String userinfo;

  public A(int sid,String password){
    this.sid = sid;
    this.userinfo = password;
  }
}

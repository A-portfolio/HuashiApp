package com.muxistudio.appcommon.appbase;

import android.os.Bundle;
import android.support.annotation.Nullable;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/5/4
 */

public class MultiStatusActivity extends ToolbarActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}

package com.muxistudio.appcommon.view;

public class IFlowView {
}

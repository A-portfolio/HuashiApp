package com.muxistudio.appcommon.data;

/**
 * Created by ybao (ybaovv@gmail.com)
 * Date: 17/4/24
 */

public class InfoCookie {

    public String Bigipserverpool_Jwc_Xk;
    public String Jsessionid;

    public InfoCookie(String bigipserverpool_Jwc_Xk, String jsessionid) {
        Bigipserverpool_Jwc_Xk = bigipserverpool_Jwc_Xk;
        Jsessionid = jsessionid;
    }
}
